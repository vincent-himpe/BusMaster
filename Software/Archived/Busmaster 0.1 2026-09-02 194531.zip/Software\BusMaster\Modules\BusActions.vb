' ============================================================================
'  Modules\BusActions.vb
'
'  Everything the Bus menu does - the operations that talk to the I2C hardware.
'
'  The routines are wired up and reachable from the menu, but the bodies are
'  still placeholders - they report to the status bar and nothing more. Replace
'  one body at a time as the real work lands.
' ============================================================================

Public Module BusActions

    ''' <summary>Bus / Scan Bus - walk the address range and list what answers.</summary>
    Public Sub ScanBus()

        ' TODO: address sweep, then report how many devices answered.
        AppCore.ReportNotImplemented("Scan Bus")

    End Sub

    ''' <summary>Bus / Poll Bus - read the configured devices repeatedly.</summary>
    Public Sub PollBus()

        ' TODO: start and stop a repeating read of the project's devices.
        AppCore.ReportNotImplemented("Poll Bus")

    End Sub

    ''' <summary>Bus / Reset Bus - clear a hung bus and put the master back to idle.</summary>
    Public Sub ResetBus()

        ' TODO: clock out a stuck slave, then issue a stop condition.
        AppCore.ReportNotImplemented("Reset Bus")

    End Sub

End Module
