' ============================================================================
'  Modules\AppCore.vb
'
'  All of the application's active code. The window's event handlers do nothing
'  but call into here, which is why "Open" can be driven from the File menu, the
'  toolbar button and Ctrl+O without three copies of the logic.
'
'  Public entry points:
'
'      Attach              wire the module to the window (called once, on Loaded)
'      NewProject          start an empty project
'      OpenProject         pick a project file and load it
'      OpenRecentProject   load the project behind an MRU menu item
'      SaveProject         save to the current path, or ask if there is none
'      SaveProjectAs       always ask for a path
'      ShowHelp            show the help box
'      ExitApplication     close the window
'      MarkModified        flag the open project as having unsaved changes
'      SetStatus           write to the right-hand status bar field
' ============================================================================

Imports System.ComponentModel
Imports System.IO
Imports Microsoft.Win32

Public Module AppCore

    Public Const ProjectExtension As String = ".bmproj"
    Private Const ProjectFilter As String = "BusMaster Project (*.bmproj)|*.bmproj|All Files (*.*)|*.*"
    Private Const UntitledName As String = "Untitled"
    Private Const AppName As String = "BusMaster"

    ''' <summary>
    ''' TEMPORARY. Loaded into the workspace panel at start-up so the layout can be
    ''' looked at. Delete this and the call in Attach once devices are opened for
    ''' real from a project.
    ''' </summary>
    Private Const DemoDeviceName As String = "PCA9555"

    ''' <summary>
    ''' The program's display name - "BusMaster 0.1". Used for the title bar and as
    ''' the caption of every message box.
    ''' </summary>
    Private ReadOnly Property AppTitle As String
        Get
            Return AppName & " " & AppSettings.ApplicationVersion
        End Get
    End Property

    ' The window this module drives. Set once by Attach.
    Private Shell As MainWindow

    ''' <summary>
    ''' The main window, for anything that needs an owner for a dialog.
    ''' </summary>
    Public ReadOnly Property MainShell As MainWindow
        Get
            Return Shell
        End Get
    End Property

    ''' <summary>The project currently open, or Nothing when there is none.</summary>
    Public Property CurrentProject As ProjectData

    ''' <summary>Where the open project lives, or an empty string if never saved.</summary>
    Public Property CurrentProjectPath As String = String.Empty

    ''' <summary>True when the open project has changes that are not on disk.</summary>
    Public Property IsModified As Boolean = False


    ' ========================================================================
    '  Start-up and shutdown
    ' ========================================================================

    ''' <summary>
    ''' Connects the module to the main window and brings the UI up to date.
    ''' Called from Window_Loaded.
    ''' </summary>
    Public Sub Attach(window As MainWindow)

        Shell = window

        WindowTheme.ApplyDarkTitleBar(Shell)

        If AppSettings.Load() Then
            SetStatus("Ready")
        Else
            SetStatus("Settings not read (" & AppSettings.LastError & ") - using defaults")
        End If

        RestoreWindowGeometry()
        RefreshRecentMenu()
        UpdateActiveProject()

        ' TEMPORARY - see DemoDeviceName. A missing file just raises LoadFailed and
        ' writes to the status bar, so this cannot stop the program starting.
        Shell.dvp_Device.LoadDevice(DemoDeviceName)

    End Sub

    ''' <summary>Asks the user to close the window. The Closing handler does the rest.</summary>
    Public Sub ExitApplication()

        If Shell Is Nothing Then Exit Sub
        Shell.Close()

    End Sub

    ''' <summary>
    ''' Everything that has to happen before the window closes. Called from
    ''' Window_Closing, so Alt+F4 and the caption's X behave like File / Exit.
    ''' </summary>
    Public Sub HandleWindowClosing(e As CancelEventArgs)

        If AppSettings.Current.ConfirmOnExit Then
            Dim answer As MessageBoxResult = MessageBox.Show(
                Shell,
                "Close " & AppTitle & "?",
                AppTitle,
                MessageBoxButton.OKCancel,
                MessageBoxImage.Question)

            If answer <> MessageBoxResult.OK Then
                e.Cancel = True
                SetStatus("Exit cancelled")
                Exit Sub
            End If
        End If

        If Not ConfirmDiscardChanges() Then
            e.Cancel = True
            SetStatus("Exit cancelled")
            Exit Sub
        End If

        StoreWindowGeometry()

    End Sub


    ' ========================================================================
    '  Project commands
    ' ========================================================================

    ''' <summary>Starts a new, unsaved project.</summary>
    Public Sub NewProject()

        If Not ConfirmDiscardChanges() Then
            SetStatus("New project cancelled")
            Exit Sub
        End If

        CurrentProject = New ProjectData With {
            .ProjectName = UntitledName,
            .CreatedUtc = UtcStamp(),
            .ModifiedUtc = UtcStamp()
        }

        CurrentProjectPath = String.Empty
        IsModified = True

        UpdateActiveProject()
        SetStatus("New project created - not saved yet")

    End Sub

    ''' <summary>Asks for a project file and loads it.</summary>
    Public Sub OpenProject()

        If Not ConfirmDiscardChanges() Then
            SetStatus("Open cancelled")
            Exit Sub
        End If

        Dim dialog As New OpenFileDialog With {
            .Title = "Open Project",
            .Filter = ProjectFilter,
            .DefaultExt = ProjectExtension,
            .CheckFileExists = True,
            .InitialDirectory = InitialFolder()
        }

        Dim picked As Boolean? = dialog.ShowDialog(Shell)

        If Not picked.GetValueOrDefault() Then
            SetStatus("Open cancelled")
            Exit Sub
        End If

        LoadProjectFile(dialog.FileName)

    End Sub

    ''' <summary>
    ''' Loads the project behind one of the MRU menu items. The path travels on the
    ''' menu item's Tag, put there by RefreshRecentMenu.
    ''' </summary>
    Public Sub OpenRecentProject(menuSource As Object)

        Dim item As MenuItem = TryCast(menuSource, MenuItem)
        If item Is Nothing Then Exit Sub

        Dim projectPath As String = TryCast(item.Tag, String)

        If String.IsNullOrWhiteSpace(projectPath) Then
            SetStatus("That recent entry is empty")
            Exit Sub
        End If

        If Not ConfirmDiscardChanges() Then
            SetStatus("Open cancelled")
            Exit Sub
        End If

        LoadProjectFile(projectPath)

    End Sub

    ''' <summary>Saves to the current path, falling back to Save As for a new project.</summary>
    Public Function SaveProject() As Boolean

        If CurrentProject Is Nothing Then
            SetStatus("Nothing to save - no project is open")
            Return False
        End If

        If String.IsNullOrEmpty(CurrentProjectPath) Then Return SaveProjectAs()

        Return WriteProjectFile(CurrentProjectPath)

    End Function

    ''' <summary>Always asks for a path, then saves.</summary>
    Public Function SaveProjectAs() As Boolean

        If CurrentProject Is Nothing Then
            SetStatus("Nothing to save - no project is open")
            Return False
        End If

        Dim dialog As New SaveFileDialog With {
            .Title = "Save Project As",
            .Filter = ProjectFilter,
            .DefaultExt = ProjectExtension,
            .AddExtension = True,
            .OverwritePrompt = True,
            .InitialDirectory = InitialFolder(),
            .FileName = SuggestedFileName()
        }

        Dim picked As Boolean? = dialog.ShowDialog(Shell)

        If Not picked.GetValueOrDefault() Then
            SetStatus("Save cancelled")
            Return False
        End If

        Return WriteProjectFile(dialog.FileName)

    End Function

    ''' <summary>File / Options - program-wide settings.</summary>
    Public Sub ShowOptions()

        ' TODO: dark-themed options window editing AppSettings.Current, then
        '       AppSettings.Save() and RefreshRecentMenu().
        ReportNotImplemented("Options")

    End Sub

    ''' <summary>
    ''' Status bar report for commands that are wired up but not written yet.
    ''' Remove each call as its command gets a real body.
    ''' </summary>
    Public Sub ReportNotImplemented(commandName As String)

        SetStatus(commandName & " - not implemented yet")

    End Sub

    ''' <summary>
    ''' Status bar report for a value a control refused to accept. Raised by
    ''' BitFieldEditor when an out-of-range entry is committed.
    ''' </summary>
    Public Sub ReportIllegalData()

        SetStatus("Illegal Data")

    End Sub

    ''' <summary>
    ''' Status bar report for a device file that could not be read. Raised by
    ''' DevicePanel - deliberately quiet, no dialog.
    ''' </summary>
    Public Sub ReportDeviceFileMissing()

        SetStatus("File not found")

    End Sub

    ''' <summary>Shows the help box.</summary>
    Public Sub ShowHelp()

        Dim text As String =
            AppTitle & " - I2C bus mastering controller" & vbCrLf & vbCrLf &
            "File menu" & vbCrLf &
            "   Ctrl+N          New Project" & vbCrLf &
            "   Ctrl+O          Open Project" & vbCrLf &
            "   Ctrl+S          Save Project" & vbCrLf &
            "   Ctrl+Shift+S    Save Project As" & vbCrLf &
            "   F1              This help" & vbCrLf & vbCrLf &
            "Settings, options and the recent project list are kept in:" & vbCrLf &
            AppSettings.SettingsFilePath

        MessageBox.Show(Shell, text, AppTitle & " Help", MessageBoxButton.OK, MessageBoxImage.Information)
        SetStatus("Help shown")

    End Sub

    ''' <summary>
    ''' Flags the open project as changed. Call this from wherever project data is
    ''' edited, so the unsaved-changes prompt and the "*" marker work.
    ''' </summary>
    Public Sub MarkModified()

        If CurrentProject Is Nothing Then Exit Sub

        IsModified = True
        UpdateActiveProject()

    End Sub


    ' ========================================================================
    '  Project file I/O
    ' ========================================================================

    ''' <summary>Reads a project file and makes it the open project.</summary>
    Public Sub LoadProjectFile(projectPath As String)

        If String.IsNullOrWhiteSpace(projectPath) Then
            SetStatus("No project file specified")
            Exit Sub
        End If

        If Not File.Exists(projectPath) Then
            AppSettings.RemoveRecentProject(projectPath)
            RefreshRecentMenu()
            SetStatus("Project not found - " & projectPath)
            MessageBox.Show(Shell,
                            "This project file no longer exists:" & vbCrLf & vbCrLf & projectPath,
                            AppTitle, MessageBoxButton.OK, MessageBoxImage.Warning)
            Exit Sub
        End If

        Try
            Dim loaded As ProjectData = JsonFile.ReadFrom(Of ProjectData)(projectPath)

            CurrentProject = loaded
            CurrentProjectPath = Path.GetFullPath(projectPath)
            IsModified = False

            If String.IsNullOrWhiteSpace(CurrentProject.ProjectName) Then
                CurrentProject.ProjectName = Path.GetFileNameWithoutExtension(CurrentProjectPath)
            End If

            AppSettings.Current.LastProjectFolder = Path.GetDirectoryName(CurrentProjectPath)
            AppSettings.AddRecentProject(CurrentProjectPath)

            RefreshRecentMenu()
            UpdateActiveProject()
            SetStatus("Opened " & Path.GetFileName(CurrentProjectPath))

        Catch ex As Exception
            SetStatus("Open failed - " & ex.Message)
            MessageBox.Show(Shell,
                            "The project could not be opened:" & vbCrLf & vbCrLf & ex.Message,
                            AppTitle, MessageBoxButton.OK, MessageBoxImage.Error)
        End Try

    End Sub

    ''' <summary>Writes the open project to a path and records it in the MRU list.</summary>
    Private Function WriteProjectFile(projectPath As String) As Boolean

        Try
            Dim fullPath As String = Path.GetFullPath(projectPath)

            ' A project that was never named takes its name from the file.
            If String.IsNullOrWhiteSpace(CurrentProject.ProjectName) OrElse
               CurrentProject.ProjectName = UntitledName Then
                CurrentProject.ProjectName = Path.GetFileNameWithoutExtension(fullPath)
            End If

            If String.IsNullOrWhiteSpace(CurrentProject.CreatedUtc) Then
                CurrentProject.CreatedUtc = UtcStamp()
            End If

            CurrentProject.ModifiedUtc = UtcStamp()

            JsonFile.WriteTo(fullPath, CurrentProject)

            CurrentProjectPath = fullPath
            IsModified = False

            AppSettings.Current.LastProjectFolder = Path.GetDirectoryName(fullPath)
            AppSettings.AddRecentProject(fullPath)

            RefreshRecentMenu()
            UpdateActiveProject()
            SetStatus("Saved " & Path.GetFileName(fullPath))
            Return True

        Catch ex As Exception
            SetStatus("Save failed - " & ex.Message)
            MessageBox.Show(Shell,
                            "The project could not be saved:" & vbCrLf & vbCrLf & ex.Message,
                            AppTitle, MessageBoxButton.OK, MessageBoxImage.Error)
            Return False
        End Try

    End Function

    ''' <summary>
    ''' Yes / No / Cancel prompt guarding any action that would throw away unsaved
    ''' work. Returns True when the caller may proceed.
    ''' </summary>
    Private Function ConfirmDiscardChanges() As Boolean

        If CurrentProject Is Nothing OrElse Not IsModified Then Return True

        Dim answer As MessageBoxResult = MessageBox.Show(
            Shell,
            "Save changes to " & CurrentProject.ProjectName & " first?",
            AppTitle,
            MessageBoxButton.YesNoCancel,
            MessageBoxImage.Question)

        Select Case answer
            Case MessageBoxResult.Yes
                Return SaveProject()
            Case MessageBoxResult.No
                Return True
            Case Else
                Return False
        End Select

    End Function


    ' ========================================================================
    '  User interface updates
    ' ========================================================================

    ''' <summary>Writes to sbar_status - the result of the last operation.</summary>
    Public Sub SetStatus(message As String)

        If Shell Is Nothing Then Exit Sub

        Shell.sbar_status.Content = If(String.IsNullOrEmpty(message), "Ready", message)

    End Sub

    ''' <summary>
    ''' Writes to sbar_ActiveProject - the open project's name and full path - and
    ''' keeps the window title in step.
    ''' </summary>
    Private Sub UpdateActiveProject()

        If Shell Is Nothing Then Exit Sub

        Dim caption As String

        If CurrentProject Is Nothing Then
            caption = "No project"
        ElseIf String.IsNullOrEmpty(CurrentProjectPath) Then
            caption = CurrentProject.ProjectName & "   (not saved yet)"
        Else
            caption = CurrentProject.ProjectName & "   -   " & CurrentProjectPath
        End If

        If IsModified Then caption &= "   *"

        Shell.sbar_ActiveProject.Content = caption

        If CurrentProject Is Nothing Then
            Shell.Title = AppTitle
        Else
            Shell.Title = CurrentProject.ProjectName & If(IsModified, " *", "") & " - " & AppTitle
        End If

    End Sub

    ''' <summary>
    ''' Fills mnu_File_Recent_1 .. mnu_File_Recent_5 from the settings file, hiding
    ''' the slots that have no entry.
    ''' </summary>
    Public Sub RefreshRecentMenu()

        If Shell Is Nothing Then Exit Sub

        Dim slots() As MenuItem = {Shell.mnu_File_Recent_1,
                                   Shell.mnu_File_Recent_2,
                                   Shell.mnu_File_Recent_3,
                                   Shell.mnu_File_Recent_4,
                                   Shell.mnu_File_Recent_5}

        Dim recent As List(Of String) = AppSettings.Current.RecentProjects

        For index As Integer = 0 To slots.Length - 1

            Dim slot As MenuItem = slots(index)

            If index < recent.Count Then
                slot.Header = "_" & (index + 1).ToString() & "   " & EscapeAccessKeys(recent(index))
                slot.Tag = recent(index)
                slot.ToolTip = recent(index)
                slot.Visibility = Visibility.Visible
            Else
                slot.Header = String.Empty
                slot.Tag = Nothing
                slot.ToolTip = Nothing
                slot.Visibility = Visibility.Collapsed
            End If

        Next

        Shell.mnu_File_Recent_Empty.Visibility =
            If(recent.Count = 0, Visibility.Visible, Visibility.Collapsed)

    End Sub

    Private Sub RestoreWindowGeometry()

        Shell.Width = AppSettings.Current.WindowWidth
        Shell.Height = AppSettings.Current.WindowHeight

        If AppSettings.Current.WindowMaximized Then Shell.WindowState = WindowState.Maximized

    End Sub

    Private Sub StoreWindowGeometry()

        AppSettings.Current.WindowMaximized = (Shell.WindowState = WindowState.Maximized)

        ' Only a normal window reports the size worth restoring.
        If Shell.WindowState = WindowState.Normal Then
            AppSettings.Current.WindowWidth = Shell.ActualWidth
            AppSettings.Current.WindowHeight = Shell.ActualHeight
        End If

        AppSettings.Save()

    End Sub


    ' ========================================================================
    '  Small helpers
    ' ========================================================================

    ''' <summary>Sortable, culture-independent UTC timestamp for the project file.</summary>
    Private Function UtcStamp() As String
        Return DateTime.UtcNow.ToString("s") & "Z"
    End Function

    ''' <summary>Folder the file dialogs should open in.</summary>
    Private Function InitialFolder() As String

        Dim folder As String = AppSettings.Current.LastProjectFolder

        If Not String.IsNullOrWhiteSpace(folder) AndAlso Directory.Exists(folder) Then Return folder

        Return Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)

    End Function

    ''' <summary>File name to offer in the Save As dialog.</summary>
    Private Function SuggestedFileName() As String

        If Not String.IsNullOrEmpty(CurrentProjectPath) Then Return Path.GetFileName(CurrentProjectPath)

        Return CurrentProject.ProjectName & ProjectExtension

    End Function

    ''' <summary>
    ''' Doubles underscores so a path like C:\my_projects\a.bmproj does not turn its
    ''' underscore into a menu access key.
    ''' </summary>
    Private Function EscapeAccessKeys(text As String) As String

        If String.IsNullOrEmpty(text) Then Return String.Empty

        Return text.Replace("_", "__")

    End Function

End Module
