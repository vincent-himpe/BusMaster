' ============================================================================
'  Controls\DevicePanel.vb
'
'  A WPF custom control that frames one device on the bus.
'
'      +--------------------------------------------------+
'      | DeviceName                                     >  |  header, 85% grey
'      +--------------------------------------------------+
'      |                                                  |  backdrop, 75% grey
'      |   content goes here                              |
'      +--------------------------------------------------+
'
'  The triangle on the right of the header is a disclosure control: hollow orange
'  pointing right when collapsed, filled yellow pointing down when expanded. It
'  shows and hides the backdrop area.
'
'  DevicePanel derives from ContentControl, so a device's registers - a stack of
'  BitFieldEditors, most likely - can simply be written inside it in XAML.
'
'  The control holds a full 256 byte register map. SetRegisterValue and
'  GetRegisterValue are the way in and out of it.
'
'  The default template lives in Themes\Generic.xaml.
' ============================================================================

Imports System.Globalization
Imports System.IO
Imports System.Windows.Controls.Primitives
Imports System.Windows.Documents

<TemplatePart(Name:="PART_Disclosure", Type:=GetType(ToggleButton))>
<TemplatePart(Name:="PART_Content", Type:=GetType(FrameworkElement))>
Public Class DevicePanel
    Inherits ContentControl

    ''' <summary>Register addresses a byte can reach, and therefore the map size.</summary>
    Private Const RegisterCount As Integer = 256

    ''' <summary>
    ''' How far in from the panel's left edge a register's BitFieldEditor starts. Just
    ''' wide enough to read as a vertical bar down the side of the registers, tying
    ''' them together as one device.
    ''' </summary>
    Private Const RegisterIndent As Double = 20


    ''' <summary>
    ''' Raised when LoadDevice could not read the file it was given. Nothing has
    ''' changed by the time it fires; the caller decides how to say so.
    ''' </summary>
    Public Shared ReadOnly LoadFailedEvent As RoutedEvent =
        EventManager.RegisterRoutedEvent("LoadFailed", RoutingStrategy.Bubble,
                                         GetType(RoutedEventHandler), GetType(DevicePanel))

    Public Custom Event LoadFailed As RoutedEventHandler
        AddHandler(handler As RoutedEventHandler)
            Me.AddHandler(LoadFailedEvent, handler)
        End AddHandler
        RemoveHandler(handler As RoutedEventHandler)
            Me.RemoveHandler(LoadFailedEvent, handler)
        End RemoveHandler
        RaiseEvent(sender As Object, e As RoutedEventArgs)
            MyBase.RaiseEvent(e)
        End RaiseEvent
    End Event

    ''' <summary>One byte per register address. Every Byte index is in range.</summary>
    Private ReadOnly RegisterValues(RegisterCount - 1) As Byte

    ''' <summary>Path handed to the last LoadDevice call, or an empty string.</summary>
    Private LoadedFromFile As String = String.Empty

    ' Template parts.
    Private SummaryBox As TextBlock
    Private TargetBox As ComboBox
    Private TargetHost As FrameworkElement
    Private FunctionBox As TextBox

    ''' <summary>Guards the target list while it is being refilled.</summary>
    Private SuppressTargetChange As Boolean = False


    ' ========================================================================
    '  Dependency properties
    ' ========================================================================

    Public Shared ReadOnly DeviceNameProperty As DependencyProperty =
        DependencyProperty.Register("DeviceName", GetType(String), GetType(DevicePanel),
                                    New FrameworkPropertyMetadata(String.Empty, AddressOf OnHeaderChanged))

    ''' <summary>Caption shown in the header bar.</summary>
    Public Property DeviceName As String
        Get
            Return CStr(GetValue(DeviceNameProperty))
        End Get
        Set(newValue As String)
            SetValue(DeviceNameProperty, newValue)
        End Set
    End Property

    Public Shared ReadOnly DeviceAddressProperty As DependencyProperty =
        DependencyProperty.Register("DeviceAddress", GetType(Byte), GetType(DevicePanel),
                                    New FrameworkPropertyMetadata(CByte(0), AddressOf OnHeaderChanged))

    ''' <summary>The device's address on the bus.</summary>
    Public Property DeviceAddress As Byte
        Get
            Return CByte(GetValue(DeviceAddressProperty))
        End Get
        Set(newValue As Byte)
            SetValue(DeviceAddressProperty, newValue)
        End Set
    End Property

    Public Shared ReadOnly FunctionNameProperty As DependencyProperty =
        DependencyProperty.Register("FunctionName", GetType(String), GetType(DevicePanel),
                                    New FrameworkPropertyMetadata(String.Empty))

    ''' <summary>
    ''' What this device does in this design, as opposed to what part it is. Shown in
    ''' the header on the left, where the user can click it and type.
    ''' </summary>
    Public Property FunctionName As String
        Get
            Return CStr(GetValue(FunctionNameProperty))
        End Get
        Set(newValue As String)
            SetValue(FunctionNameProperty, newValue)
        End Set
    End Property

    Public Shared ReadOnly DeviceDescriptionProperty As DependencyProperty =
        DependencyProperty.Register("DeviceDescription", GetType(String), GetType(DevicePanel),
                                    New FrameworkPropertyMetadata(String.Empty, AddressOf OnHeaderChanged))

    ''' <summary>The part's own description, as the .DEV file gives it.</summary>
    Public Property DeviceDescription As String
        Get
            Return CStr(GetValue(DeviceDescriptionProperty))
        End Get
        Set(newValue As String)
            SetValue(DeviceDescriptionProperty, newValue)
        End Set
    End Property

    Public Shared ReadOnly DevicetypeProperty As DependencyProperty =
        DependencyProperty.Register("Devicetype", GetType(String), GetType(DevicePanel),
                                    New FrameworkPropertyMetadata(String.Empty))

    ''' <summary>What kind of part this is - "EEPROM", "RTC", and so on.</summary>
    Public Property Devicetype As String
        Get
            Return CStr(GetValue(DevicetypeProperty))
        End Get
        Set(newValue As String)
            SetValue(DevicetypeProperty, newValue)
        End Set
    End Property

    Public Shared ReadOnly IsExpandedProperty As DependencyProperty =
        DependencyProperty.Register("IsExpanded", GetType(Boolean), GetType(DevicePanel),
                                    New FrameworkPropertyMetadata(True))

    ''' <summary>
    ''' State of the disclosure triangle. True points it down, filled and yellow,
    ''' and shows the backdrop; False points it right, hollow and orange, and hides
    ''' the backdrop.
    ''' </summary>
    Public Property IsExpanded As Boolean
        Get
            Return CBool(GetValue(IsExpandedProperty))
        End Get
        Set(newValue As Boolean)
            SetValue(IsExpandedProperty, newValue)
        End Set
    End Property


    ' ========================================================================
    '  Construction
    ' ========================================================================

    Shared Sub New()
        DefaultStyleKeyProperty.OverrideMetadata(GetType(DevicePanel),
                                                 New FrameworkPropertyMetadata(GetType(DevicePanel)))
    End Sub

    Public Overrides Sub OnApplyTemplate()

        MyBase.OnApplyTemplate()

        SummaryBox = TryCast(GetTemplateChild("PART_Summary"), TextBlock)
        TargetHost = TryCast(GetTemplateChild("PART_TargetHost"), FrameworkElement)

        If FunctionBox IsNot Nothing Then
            RemoveHandler FunctionBox.PreviewKeyDown, AddressOf FunctionBox_PreviewKeyDown
            RemoveHandler FunctionBox.LostKeyboardFocus, AddressOf FunctionBox_LostKeyboardFocus
        End If

        FunctionBox = TryCast(GetTemplateChild("txt_FunctionName"), TextBox)

        If FunctionBox IsNot Nothing Then
            AddHandler FunctionBox.PreviewKeyDown, AddressOf FunctionBox_PreviewKeyDown
            AddHandler FunctionBox.LostKeyboardFocus, AddressOf FunctionBox_LostKeyboardFocus
        End If

        If TargetBox IsNot Nothing Then
            RemoveHandler TargetBox.SelectionChanged, AddressOf TargetBox_SelectionChanged
        End If

        TargetBox = TryCast(GetTemplateChild("PART_Target"), ComboBox)

        If TargetBox IsNot Nothing Then
            AddHandler TargetBox.SelectionChanged, AddressOf TargetBox_SelectionChanged
        End If

        RefreshHeader()

    End Sub


    ' ========================================================================
    '  Function name
    ' ========================================================================

    ''' <summary>Enter finishes the edit rather than leaving a caret blinking.</summary>
    Private Sub FunctionBox_PreviewKeyDown(sender As Object, e As KeyEventArgs)

        If e.Key <> Key.Enter Then Exit Sub

        CommitFunctionName()
        Keyboard.ClearFocus()
        e.Handled = True

    End Sub

    Private Sub FunctionBox_LostKeyboardFocus(sender As Object, e As KeyboardFocusChangedEventArgs)

        CommitFunctionName()

    End Sub

    ''' <summary>
    ''' Clicking anywhere else on the panel ends an edit in progress. WPF does not
    ''' move focus when the click lands on something that cannot take it - a label,
    ''' or bare backdrop - so without this the caret would sit there blinking.
    ''' </summary>
    Protected Overrides Sub OnPreviewMouseDown(e As MouseButtonEventArgs)

        MyBase.OnPreviewMouseDown(e)

        If FunctionBox Is Nothing Then Exit Sub
        If Not FunctionBox.IsKeyboardFocusWithin Then Exit Sub
        If FunctionBox.IsMouseOver Then Exit Sub

        Keyboard.ClearFocus()

    End Sub

    ''' <summary>
    ''' Tidies the typed name once the edit is over: trimmed, and every word
    ''' capitalised the same way register names are.
    ''' </summary>
    Private Sub CommitFunctionName()

        Dim tidied As String = TextTools.CapitaliseWords(If(FunctionName, String.Empty).Trim())

        If Not String.Equals(tidied, FunctionName, StringComparison.Ordinal) Then FunctionName = tidied

    End Sub


    ' ========================================================================
    '  Header summary
    ' ========================================================================

    Private Shared Sub OnHeaderChanged(source As DependencyObject, e As DependencyPropertyChangedEventArgs)

        Dim panel As DevicePanel = TryCast(source, DevicePanel)
        If panel IsNot Nothing Then panel.RefreshHeader()

    End Sub

    ''' <summary>
    ''' Builds the right hand caption: device name, the address it is answering on,
    ''' and what the part is - each in its own colour.
    ''' </summary>
    Private Sub RefreshHeader()

        If SummaryBox Is Nothing Then Exit Sub

        SummaryBox.Inlines.Clear()

        AddRun(DeviceName, "Brush_Header_Device")
        AddRun(" @ ", "Brush_Header_Plain")
        AddRun(FormattedAddress(), "Brush_Address_Good")
        AddRun(" : ", "Brush_Header_Plain")
        AddRun(DeviceDescription, "Brush_Header_Plain")

    End Sub

    Private Sub AddRun(text As String, brushKey As String)

        SummaryBox.Inlines.Add(New Run(If(text, String.Empty)) With {
            .Foreground = TryCast(TryFindResource(brushKey), Brush)
        })

    End Sub

    ''' <summary>
    ''' The address the panel is set to, as "0101 000 [R/W]". No masking here - this
    ''' is one particular device, not the family, so every bit is known.
    ''' </summary>
    Private Function FormattedAddress() As String

        Return I2CAddress.FormatSevenBit(I2CAddress.SevenBitAddress(CInt(DeviceAddress)))

    End Function


    ' ========================================================================
    '  Register map
    ' ========================================================================

    ''' <summary>
    ''' Stores a value against a register address. Both arguments are bytes, so
    ''' every address from 0 to 255 is valid and nothing can be out of range.
    ''' </summary>
    Public Sub SetRegisterValue(register As Byte, registervalue As Byte)

        RegisterValues(CInt(register)) = registervalue

    End Sub

    ''' <summary>
    ''' Reads back a register. Addresses never written return zero.
    ''' </summary>
    Public Function GetRegisterValue(register As Byte) As Byte

        Return RegisterValues(CInt(register))

    End Function

    ''' <summary>
    ''' Reads a .DEV file and builds the panel from it: the header takes the device's
    ''' name and address, and every register in the file becomes a BitFieldEditor
    ''' stacked down the backdrop.
    '''
    ''' Takes a bare name - "ABCD" finds devices\ABCD.DEV - or a full path.
    '''
    ''' A file that cannot be found or read is not an error worth interrupting for:
    ''' nothing changes and LoadFailed is raised so the caller can put it in the
    ''' status bar. No dialogs.
    ''' </summary>
    Public Sub LoadDevice(devicefile As String)

        Dim resolved As String = ResolveDeviceFile(devicefile)

        If resolved.Length = 0 Then
            MyBase.RaiseEvent(New RoutedEventArgs(LoadFailedEvent, Me))
            Exit Sub
        End If

        Dim data As DeviceFileData

        Try
            data = DeviceLibrary.LoadDeviceFile(resolved)
        Catch
            MyBase.RaiseEvent(New RoutedEventArgs(LoadFailedEvent, Me))
            Exit Sub
        End Try

        LoadedFromFile = resolved

        ApplyDeviceHeader(data)
        ApplyTargetAddresses(data)
        BuildRegisterEditors(data)

    End Sub

    ''' <summary>
    ''' Turns whatever was passed in into a file that exists, or an empty string.
    ''' Tries it as given first, then as a name in the device library.
    ''' </summary>
    Private Function ResolveDeviceFile(devicefile As String) As String

        If String.IsNullOrWhiteSpace(devicefile) Then Return String.Empty

        Dim candidate As String = devicefile.Trim()

        Try
            If File.Exists(candidate) Then Return candidate

            ' "ABCD" and "ABCD.DEV" both mean devices\ABCD.DEV.
            Dim inLibrary As String = DeviceLibrary.PathFor(Path.GetFileNameWithoutExtension(candidate))
            If File.Exists(inLibrary) Then Return inLibrary

        Catch
            ' A malformed path is just a file that is not there.
        End Try

        Return String.Empty

    End Function

    ''' <summary>Header fields that the .DEV file actually carries.</summary>
    Private Sub ApplyDeviceHeader(data As DeviceFileData)

        DeviceName = If(data.DeviceName, String.Empty).Trim()
        DeviceDescription = If(data.DeviceDescription, String.Empty).Trim()

        Dim baseAddress As Integer

        If Integer.TryParse(If(data.BaseAddress, String.Empty).Trim(), NumberStyles.None,
                            CultureInfo.InvariantCulture, baseAddress) AndAlso
           baseAddress >= 0 AndAlso baseAddress <= Byte.MaxValue Then

            DeviceAddress = CByte(baseAddress)

        End If

        ' The file has no device type field, so Devicetype is left as the caller set it.

    End Sub

    ''' <summary>
    ''' One BitFieldEditor per register, stacked. Each starts RegisterIndent in from
    ''' the panel's left edge and runs to its right edge, so they grow with the panel.
    ''' </summary>
    Private Sub BuildRegisterEditors(data As DeviceFileData)

        ' Two columns: the gutter that holds the target selector, and the registers.
        Dim layout As New Grid()
        layout.ColumnDefinitions.Add(New ColumnDefinition With {.Width = New GridLength(RegisterIndent)})
        layout.ColumnDefinitions.Add(New ColumnDefinition With {.Width = New GridLength(1, GridUnitType.Star)})

        Dim rowIndex As Integer = 0

        If data.Registers IsNot Nothing Then

            For Each register As DeviceRegisterData In data.Registers

                If register Is Nothing Then Continue For

                layout.RowDefinitions.Add(New RowDefinition With {.Height = GridLength.Auto})

                Dim editor As New BitFieldEditor With {
                    .Registername = If(register.RegisterName, String.Empty),
                    .Registeraddress = ToRegisterAddress(register.RegisterAddress),
                    .Fieldnames = BitNameList(register),
                    .HorizontalAlignment = HorizontalAlignment.Stretch
                }

                ' Every editor draws its own one pixel border. Dropping the top edge
                ' on all but the first leaves a single hairline between them instead
                ' of two touching edges.
                editor.BorderThickness = If(rowIndex = 0, New Thickness(1), New Thickness(1, 0, 1, 1))

                Grid.SetRow(editor, rowIndex)
                Grid.SetColumn(editor, 1)
                layout.Children.Add(editor)

                rowIndex += 1

            Next

        End If

        Me.Content = layout

        ' There is something to look at now.
        IsExpanded = True

    End Sub

    ''' <summary>
    ''' Fills the header's target list with every address this part can be strapped
    ''' to, and selects the one it is currently answering on.
    ''' </summary>
    Private Sub ApplyTargetAddresses(data As DeviceFileData)

        If TargetBox Is Nothing Then Exit Sub

        Dim addresses As List(Of Integer) = TargetAddresses(data)

        ' Refilling the list churns the selection, which would otherwise write a
        ' half-built value back into DeviceAddress.
        SuppressTargetChange = True

        TargetBox.ItemsSource = addresses
        TargetBox.SelectedItem = CInt(DeviceAddress)
        If TargetBox.SelectedIndex < 0 Then TargetBox.SelectedIndex = 0

        SuppressTargetChange = False

        If TargetHost IsNot Nothing Then TargetHost.Visibility = Visibility.Visible

    End Sub

    ''' <summary>
    ''' Base address, then one more for every value the address pins can take. Stops
    ''' at 255 rather than wrapping.
    ''' </summary>
    Private Function TargetAddresses(data As DeviceFileData) As List(Of Integer)

        Dim addresses As New List(Of Integer)

        Dim bits As Integer
        If Not Integer.TryParse(If(data.AddressBits, String.Empty).Trim(), NumberStyles.None,
                                CultureInfo.InvariantCulture, bits) Then bits = 0

        If bits < 0 Then bits = 0
        If bits > I2CAddress.MaxAddressBits Then bits = I2CAddress.MaxAddressBits

        Dim first As Integer = CInt(DeviceAddress)

        For offset As Integer = 0 To (1 << bits) - 1

            Dim address As Integer = first + offset
            If address > Byte.MaxValue Then Exit For

            addresses.Add(address)

        Next

        If addresses.Count = 0 Then addresses.Add(first)

        Return addresses

    End Function

    Private Sub TargetBox_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)

        If SuppressTargetChange Then Exit Sub
        If TargetBox Is Nothing OrElse TargetBox.SelectedItem Is Nothing Then Exit Sub

        ' Drives DeviceAddress, which is what the header caption reads.
        DeviceAddress = CByte(CInt(TargetBox.SelectedItem))

    End Sub

    ''' <summary>
    ''' BitFieldEditor takes its captions most significant bit first, which is the
    ''' order D7 down to D0 is written in.
    ''' </summary>
    Private Shared Function BitNameList(register As DeviceRegisterData) As String

        Return String.Join(",", {register.D7, register.D6, register.D5, register.D4,
                                 register.D3, register.D2, register.D1, register.D0})

    End Function

    ''' <summary>
    ''' Registeraddress is a Byte, so -1 - a device with no register addressing at
    ''' all - cannot be held. It becomes 0, which is the only register such a device
    ''' has anyway.
    ''' </summary>
    Private Shared Function ToRegisterAddress(address As Integer) As Byte

        If address <= 0 Then Return 0
        If address >= Byte.MaxValue Then Return Byte.MaxValue

        Return CByte(address)

    End Function

End Class
