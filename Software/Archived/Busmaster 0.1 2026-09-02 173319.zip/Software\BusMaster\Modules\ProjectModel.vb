' ============================================================================
'  Modules\ProjectModel.vb
'
'  What a BusMaster project file (*.bmproj) contains. Same rules as the settings
'  file: strings, numbers and Booleans only, written indented so the file can be
'  read and diffed by hand.
'
'  The bus fields below are placeholders for the real I2C configuration - they
'  exist so the save/load path is exercised end to end.
' ============================================================================

Public Class ProjectData

    Public Property SchemaVersion As Integer = 1
    Public Property ProjectName As String = "Untitled"
    Public Property Description As String = String.Empty
    Public Property CreatedUtc As String = String.Empty
    Public Property ModifiedUtc As String = String.Empty

    ' -- I2C bus configuration ------------------------------------------------
    Public Property BusSpeedKhz As Integer = 100
    Public Property AddressBits As Integer = 7
    Public Property EnablePullups As Boolean = True

End Class
