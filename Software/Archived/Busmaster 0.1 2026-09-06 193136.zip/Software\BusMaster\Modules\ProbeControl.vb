' ============================================================================
'  Modules\ProbeControl.vb
'
'  The probe on the other end of the USB serial link: what goes out to it, and
'  what comes back.
'
'  Two routines, and every byte passes through one of them:
'
'      ProbeSend      a line on its way out to the probe
'      ProbeReceive   a line that has arrived from it
'
'  Both are deliberately thin for now. Whatever has to be done to a line - a
'  checksum, a framing character, a reply matched to its request - belongs inside
'  these two and nowhere else, the same way every register operation goes through
'  ReadRegister and WriteRegister.
'
'  The port itself is named in settings.json, not in the project: which COM port
'  a probe turns up on belongs to the machine. Leave ProbePort blank and the
'  link turns lines straight round instead, so the Terminal is usable with no
'  hardware attached.
' ============================================================================

Imports System.IO.Ports
Imports System.Text
Imports System.Windows.Threading

Public Module ProbeControl

    ''' <summary>What ends a line on the wire.</summary>
    Public Const LineEnding As String = vbCrLf

    Private Port As SerialPort

    ''' <summary>
    ''' Bytes that have arrived but do not make a whole line yet. Only ever touched
    ''' on the UI thread - see Port_DataReceived.
    ''' </summary>
    Private ReadOnly Arriving As New StringBuilder()

    ''' <summary>
    ''' Set once a port has been reported broken, so a failing link complains once
    ''' rather than on every line.
    ''' </summary>
    Private Complained As Boolean = False


    ' ========================================================================
    '  Out
    ' ========================================================================

    ''' <summary>
    ''' Sends a line to the probe. For now it goes out exactly as it was handed
    ''' over, with a carriage return and line feed on the end.
    ''' </summary>
    Public Sub ProbeSend(text As String)

        ' TODO: whatever the line needs doing to it before it goes out.

        Transmit(If(text, String.Empty) & LineEnding)

    End Sub


    ' ========================================================================
    '  In
    ' ========================================================================

    ''' <summary>
    ''' Takes a line that has arrived from the probe. Splitting the incoming bytes
    ''' into lines is the port's business; making sense of a line is this routine's.
    '''
    ''' Always called on the UI thread - the port hands its data over on a worker
    ''' thread and that is marshalled before it gets this far.
    ''' </summary>
    Public Sub ProbeReceive(text As String)

        ' TODO: whatever has to be made of the line that came back.

        TerminalCore.ShowReceived(If(text, String.Empty))

    End Sub


    ' ========================================================================
    '  The port
    ' ========================================================================

    ''' <summary>Whether there is a port open to the probe right now.</summary>
    Public ReadOnly Property IsConnected As Boolean
        Get
            Return Port IsNot Nothing AndAlso Port.IsOpen
        End Get
    End Property

    ''' <summary>The name the settings give for the probe's port, trimmed.</summary>
    Private ReadOnly Property WantedPort As String
        Get
            Return If(AppSettings.Current.ProbePort, String.Empty).Trim()
        End Get
    End Property

    ''' <summary>
    ''' The port that is open right now, or an empty string. Not the same as the one
    ''' the settings name - that is the one to use next.
    ''' </summary>
    Public ReadOnly Property PortInUse As String
        Get
            If Not IsConnected Then Return String.Empty

            Return Port.PortName
        End Get
    End Property

    ''' <summary>
    ''' Tells whatever shows the state of the link that it has changed. One place,
    ''' so a connection made from the toolbar and one made by the first line going
    ''' out both end up on screen the same way.
    ''' </summary>
    Private Sub LinkChanged()

        OnUiThread(Sub()
                       AppCore.RefreshProbeConnection()
                       TerminalCore.ShowProbeState()
                   End Sub)

    End Sub

    ''' <summary>Serial ports this machine currently has, for whatever offers a choice.</summary>
    Public Function AvailablePorts() As String()

        Try
            Return SerialPort.GetPortNames()
        Catch
            Return New String() {}
        End Try

    End Function

    ''' <summary>
    ''' Chooses which port the probe is on and remembers it. Anything already open
    ''' is closed first - the name is which port to use next, not which one is in
    ''' use now.
    ''' </summary>
    Public Sub ChoosePort(portName As String)

        Dim wanted As String = If(portName, String.Empty).Trim()

        If String.Equals(wanted, WantedPort, StringComparison.OrdinalIgnoreCase) Then Exit Sub

        Disconnect()

        AppSettings.Current.ProbePort = wanted
        AppSettings.Save()

        Complained = False

        If wanted.Length = 0 Then
            AppCore.SetStatus("Probe port cleared - the Terminal will turn lines straight round")
        Else
            AppCore.SetStatus("Probe port set to " & wanted)
        End If

    End Sub

    ''' <summary>
    ''' Opens the configured port if it is not open already. Reports a failure once
    ''' and then stays quiet, so a probe that is not plugged in does not fill the
    ''' transcript with the same complaint.
    ''' </summary>
    Public Function Connect() As Boolean

        If IsConnected Then Return True

        If WantedPort.Length = 0 Then Return False

        Try
            Port = New SerialPort(WantedPort, AppSettings.Current.ProbeBaud) With {
                .Encoding = Encoding.ASCII,
                .NewLine = LineEnding,
                .ReadTimeout = 500,
                .WriteTimeout = 500,
                .DtrEnable = True
            }

            AddHandler Port.DataReceived, AddressOf Port_DataReceived

            Port.Open()

            Complained = False
            Report("Probe connected on " & WantedPort)
            LinkChanged()

            Return True

        Catch ex As Exception

            Port = Nothing
            Complain("Probe port " & WantedPort & " would not open - " & ex.Message)
            LinkChanged()

            Return False

        End Try

    End Function

    ''' <summary>Closes the port. Safe to call when there is nothing open.</summary>
    Public Sub Disconnect()

        If Port Is Nothing Then Exit Sub

        Try
            RemoveHandler Port.DataReceived, AddressOf Port_DataReceived
            If Port.IsOpen Then Port.Close()
        Catch
            ' Closing a port that has already gone - a USB probe unplugged mid-run -
            ' throws, and there is nothing useful to do about it.
        End Try

        Port.Dispose()
        Port = Nothing

        LinkChanged()

    End Sub

    Private Sub Transmit(text As String)

        ' No port named: turn the line straight round, so the Terminal is worth
        ' opening before any hardware exists. This is the whole of the stand-in.
        If WantedPort.Length = 0 Then
            OnUiThread(Sub() Absorb(text))
            Exit Sub
        End If

        If Not Connect() Then Exit Sub

        Try
            Port.Write(text)
        Catch ex As Exception
            Complain("Probe write failed - " & ex.Message)
            Disconnect()
        End Try

    End Sub

    ''' <summary>
    ''' The port's own event, raised on a worker thread. Nothing but the read
    ''' happens here: the text is handed to the UI thread before it is looked at,
    ''' which is what lets everything downstream ignore threading altogether.
    ''' </summary>
    Private Sub Port_DataReceived(sender As Object, e As SerialDataReceivedEventArgs)

        Dim arrived As String

        Try
            arrived = Port.ReadExisting()
        Catch
            Exit Sub
        End Try

        If arrived.Length = 0 Then Exit Sub

        OnUiThread(Sub() Absorb(arrived))

    End Sub

    ''' <summary>
    ''' Collects arriving text and lets whole lines through. A reply can be split
    ''' across any number of reads, so the tail is kept until its line finishes.
    ''' </summary>
    Private Sub Absorb(arrived As String)

        Arriving.Append(arrived)

        Dim pending As String = Arriving.ToString()
        Dim ends As Integer = pending.IndexOf(ControlChars.Lf)

        While ends >= 0

            ProbeReceive(pending.Substring(0, ends).TrimEnd(ControlChars.Cr))

            pending = pending.Substring(ends + 1)
            ends = pending.IndexOf(ControlChars.Lf)

        End While

        Arriving.Clear()
        Arriving.Append(pending)

    End Sub

    Private Sub OnUiThread(work As Action)

        Dim application As System.Windows.Application = System.Windows.Application.Current

        If application Is Nothing Then
            work()
            Exit Sub
        End If

        application.Dispatcher.BeginInvoke(DispatcherPriority.Normal, work)

    End Sub

    ''' <summary>Says something once. The next success clears the slate.</summary>
    Private Sub Complain(message As String)

        If Complained Then Exit Sub

        Complained = True
        Report(message)

    End Sub

    Private Sub Report(message As String)

        OnUiThread(Sub()
                       AppCore.SetStatus(message)
                       TerminalCore.ShowNotice(message)
                   End Sub)

    End Sub

End Module
